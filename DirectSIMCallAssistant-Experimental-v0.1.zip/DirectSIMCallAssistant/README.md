# Personal Call Assistant — Direct SIM Experiment v0.1

An experimental Android default-dialer proof of concept for a Motorola Edge 70 Fusion / Android 17. It is designed to work with the phone's own SIM call path: no call forwarding, SIP account, telephony provider, or backend server is included.

## Implemented in this prototype

- Agent Mode ON/OFF stored locally.
- Default Phone App role request.
- Android `InCallService` receives call events and can answer/disconnect calls.
- When Agent Mode is ON, the app attempts to auto-answer incoming calls.
- Experimental speakerphone acoustic route plus Android speech recognition.
- Spoken menu: say "one" to save a note, "two" to save a callback reminder, or "three" to end the call.
- Android Text-to-Speech prompts and confirmations.
- Notes/reminders stored locally on the device.
- When Agent Mode is OFF, the app does not auto-answer; Android should continue ringing and the user can answer manually.

## Critical limitations — read before installing

This is an **experimental proof of concept**, not a verified working cellular voice agent. `InCallService` can control a call when this app is the default dialer, but it does not grant direct access to the protected cellular call audio stream. The prototype tries an acoustic workaround: route the call to speakerphone and let Android speech recognition use the phone microphone. Motorola firmware, Android audio policy, carrier configuration, privacy controls, or the speech-recognition service may block or interrupt this. If the microphone is blocked, the agent cannot understand the caller. Text-to-speech may also fail to reach the caller.

- No keypad DTMF detection is implemented. The caller must speak the menu choice.
- English (India) is the only configured recognition language in this first experiment.
- No Gemini/OpenAI API is used; the prototype does not need a backend.
- The app has not been compiled or tested on a Motorola Edge 70 Fusion in this environment.
- Do not use it for important calls, emergencies, confidential messages, or unattended production use.
- Test only with someone who knows the call is being handled by an experimental assistant.
- Keep Motorola Phone available. To revert, change Android Settings → Apps → Default apps → Phone app back to Motorola Phone.

## Build an APK using only your phone (GitHub Actions)

The ZIP contains Android source code, not an APK. GitHub Actions can compile it in the cloud; you do not need a laptop.

1. On your phone, open GitHub in Chrome and create a **new empty repository** (for example `personal-call-assistant`).
2. In that repository, use **Add file → Upload files** and upload this ZIP file itself to the repository root. Commit it.
3. In the repository, choose **Add file → Create new file**.
4. Name the new file exactly `.github/workflows/build-apk.yml`.
5. Paste the workflow below and commit it.
6. Open the repository's **Actions** tab. Open **Build Direct-SIM APK**. If asked, enable GitHub Actions.
7. Wait for the workflow to finish. Open the successful run, scroll to **Artifacts**, and download `Personal-Call-Assistant-debug-apk`.
8. Extract the downloaded artifact ZIP on your phone and tap `app-debug.apk`. Allow Chrome/Files to install unknown apps if Android asks.

### Workflow to paste into `.github/workflows/build-apk.yml`

```yaml
name: Build Direct-SIM APK
on:
  workflow_dispatch:
  push:
    paths:
      - 'DirectSIMCallAssistant-Experimental-v0.1.zip'
      - '.github/workflows/build-apk.yml'
permissions:
  contents: read
jobs:
  build:
    runs-on: ubuntu-latest
    steps:
      - uses: actions/checkout@v4
      - name: Unpack Android project
        run: |
          unzip DirectSIMCallAssistant-Experimental-v0.1.zip -d project
          test -f project/DirectSIMCallAssistant/app/build.gradle.kts
      - uses: actions/setup-java@v4
        with:
          distribution: temurin
          java-version: '17'
      - uses: gradle/actions/setup-gradle@v4
        with:
          gradle-version: '8.13'
      - uses: android-actions/setup-android@v3
      - name: Install Android SDK platform
        run: sdkmanager "platforms;android-36" "build-tools;36.0.0"
      - name: Build debug APK
        working-directory: project/DirectSIMCallAssistant
        run: gradle --no-daemon :app:assembleDebug
      - uses: actions/upload-artifact@v4
        with:
          name: Personal-Call-Assistant-debug-apk
          path: project/DirectSIMCallAssistant/app/build/outputs/apk/debug/app-debug.apk
          retention-days: 14
```

The generated APK is debug-signed and intended only for personal testing. A production release needs a private signing key and more security/reliability work.

## Install and test

1. Install and open the APK.
2. Grant microphone permission when enabling Agent Mode.
3. Tap **Set as default phone app** and approve Android's role prompt.
4. Verify the main screen says **Default phone app is selected**.
5. Turn Agent Mode ON.
6. Ask a consenting friend to call your SIM from another phone. Start with a harmless test phrase.
7. Check whether the caller hears the greeting, whether the app recognizes "one", and whether the saved text appears in Notes & reminders.
8. Repeat with Agent Mode OFF and verify that the call rings normally and is not auto-answered.

If calls do not ring correctly or audio behaves unexpectedly, immediately switch the default Phone app back to Motorola Phone.

## Project details

- Package: `com.aryan.directsim`
- Min SDK: 26
- Compile SDK: 36
- Target SDK: 35
- Java: 17
- Android: Kotlin, Jetpack Compose, Android Telecom, SpeechRecognizer, TextToSpeech
